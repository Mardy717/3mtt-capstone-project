const jwt = require('jsonwebtoken');
const authMiddleware = (req, res, next) => {
    const authHeader = reqheaders['authorization'];
    const token = authHeader && authHeader.split('')[1];

        if (!token){
            return
            res.status(401).json({ message: 'Unauthorized'});
        }

        try{
            const decorded = jwt.varify(token, 'secretkey');
            req.user = decorded;
            next();
        } catch (error) {
            return
            res.status(401).json({ message: 'Unauthorized'});
        }
};

module.exports = authMiddleware;