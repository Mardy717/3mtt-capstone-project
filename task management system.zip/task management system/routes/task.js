const express = require('express');
const router = express.Router();
const Task = require('../models/task'); // Task model
const { title } = require('process');

//add new task
router.post('/tasks', async (req, res) => {
  try {
    const { title, description, deadline, priority } = req.body;
    const newTask = new Task({ title, description, deadline, priority, userId });
    await newTask.save();
    res.status(201).json(newTaskSave);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// fetching task
router.get('/users/:userId/tasks', async (req, res) => {
  try {
    const userId = req.params.userId;
    const tasks = await Task.find({ userId });
    res.json(tasks);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching tasks' });
  }
});

//task details
router.get('/tasks/:TaskId', async (req, res) => {
  try {
    const TaskId = req.params.TaskId;
    const Task = await Task.findById(TaskId);

    if (!Task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json(Task);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching Task details' });
  }
});

//updating task
router.put('/tasks/:TaskId', async (req, res) => {
  try {
    const TaskId = req.params.TaskId;
    const { title, description, priority, dueDate } = req.body;

    const updatedTask = await Task.findByIdAndUpdate(
      TaskId,
      { title, description, priority, dueDate },
      { new: true } // Return the updated document
    );

    if (!updatedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json(updatedTask);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating Task' });
  }
});

//deleting task
router.delete('/tasks/:TaskId', async (req, res) => {
  try {
    const TaskId = req.params.TaskId;
    const deletedTask = await Task.findByIdAndDelete(TaskId);

    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting Task' });
  }
});

//filter task
router.get('/tasks', async (req, res) => {
  try {
    const { title, priority } = req.query;
    const filters = {};

    if (title) {
      filters.title = title;
    }

    if (priority) {
      filters.priority = priority;
    }

    const tasks = await Task.find(filters);
    res.json(tasks);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching tasks' });
  }
});

//report generation
router.get('/generate-report', async (req, res) => {
  try {
    // Logic to generate the report
    const tasks = await Task.find();
    // Create the report data (e.g., calculate totals, create charts)

    // Send the report data to the client (you can use a templating engine or send raw data)
    res.json(reportData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error generating report' });
  }
});

module.exports = router;