const registrationForm = document.getElementById('registration-form');
registrationForm.addEventListener('submit', function(event) {
    event.preventDefault();

    // Get references to form elements
    const usernameInput = document.getElementById('username');
    const fullNameInput = document.getElementById('full-name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');
    const genderSelect = document.getElementById('gender');
    const termsCheckbox = document.getElementById('terms');

    // Basic form validation
    if (usernameInput.value === '') {
        alert('Please enter a username');
        return;
    }
    
    if (fullNameInput.value === '') {
        alert('Please enter your full name');
        return;
    }

    if (emailInput.value === '') {
        alert('Please enter an email address');
        return;
    }

    if (passwordInput.value === '') {
        alert('Please enter a password');
        return;
    }

    if (confirmPasswordInput.value !== passwordInput.value) {
        alert('Passwords do not match');
        return;
    }
    
    if (genderSelect.value === '') {
        alert('Please select a gender');
        return;
    }

    if (!termsCheckbox.checked) {
        alert('Please agree to the terms of service');
        return;
    }

    // Form is valid, submit data to server
    // ... form validation code ...
const formData = {
    username: usernameInput.value,
    full_name: fullNameInput.value,
    email: emailInput.value,
    password: passwordInput.value,
    gender: genderSelect.value
};

fetch('/register', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
})
.then(response => {
    if (response.ok) {
        console.log('Registration successful');
        // Handle successful registration, e.g., redirect to login page
    } else {
        console.error('Registration failed');
        // Handle registration error
    }
})
.catch(error => {
    console.error('Error:', error);
});

});


// addTaskForm
const addTaskForm = document.getElementById('add-task-form');
addTaskForm.addEventListener('submit', (event) => {
  event.preventDefault();

  // Get form data
  const taskTitle = document.getElementById('task-title').value;
  const taskDescription = document.getElementById('task-description').value;
  const taskDeadline = document.getElementById('task-deadline').value;
  const taskPriority = document.getElementById('task-priority').value;

  // Create a new task object
  const newTask = {
    title: taskTitle,
    description: taskDescription,
    deadline: taskDeadline,
    priority: taskPriority
  };

  // Send the task data to the server
  fetch('/tasks', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(newTask)
  })
  .then(response => {
    if (response.ok) {
      console.log('Task added successfully');
      // Clear the form or display a success message
    } else {
      console.error('Error adding task');
    }
  })
  .catch(error => {
    console.error('Error:', error);
  });
});
