function checkAuthentication() {
    const token = localStorage.getItem('token');
    if (!token) {
      // Redirect to login page
      window.location.href = '/login';
    }
  }
  
  // Call the checkAuthentication function on page load
  checkAuthentication();