// Get references to elements
const taskList = document.getElementById('tasks');
const taskDetailsSection = document.querySelector('.task-details');
const addTaskForm = document.getElementById('add-task-form');

// Function to fetch and display tasks
function fetchAndDisplayTasks() {
  fetch('/tasks')
    .then(response => response.json())
    .then(tasks => {
      const tasksListElement = document.getElementById('tasks');
      tasksListElement.innerHTML = '';

      tasks.forEach(task => {
        const listItem = document.createElement('li');
        listItem.textContent = task.title;
        listItem.dataset.taskId = task._id;
        tasksListElement.appendChild(listItem);
      });
    })
    .catch(error => {
      console.error('Error fetching tasks:', error);
    });
}

// Initial fetch of tasks
fetchAndDisplayTasks();

// Event listener for clicking on a task
taskList.addEventListener('click', (event) => {
  if (event.target.tagName === 'LI') {
    const taskId = event.target.dataset.taskId;

    fetch(`/tasks/${taskId}`)
      .then(response => response.json())
      .then(task => {
        // Update task details section
        const taskTitleElement = taskDetailsSection.querySelector('#task-title');
        const taskDescriptionElement = taskDetailsSection.querySelector('#task-description');
        const taskDeadlineElement = taskDetailsSection.querySelector('#task-deadline');
        const taskPriorityElement = taskDetailsSection.querySelector('#task-priority');

        taskTitleElement.textContent = task.title;
        taskDescriptionElement.textContent = task.description;
        taskDeadlineElement.textContent = task.deadline;
        taskPriorityElement.textContent = task.priority;
      })
      .catch(error => {
        console.error('Error fetching task details:', error);
      });
  }
});

// Event listener for adding a new task
addTaskForm.addEventListener('submit', (event) => {
  event.preventDefault();

  // Get form data
  const taskTitle = document.getElementById('task-title').value;
  const taskDescription = document.getElementById('task-description').value;
  const taskDeadline = document.getElementById('task-deadline').value;
  const taskPriority = document.getElementById('task-priority').value;

  // Create a new task object
  const newTask = {
    title: taskTitle,
    description: taskDescription,
    deadline: taskDeadline,
    priority: taskPriority
  };

  // Send the task data to the server
  fetch('/tasks', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(newTask)
  })
  .then(response => {
    if (response.ok) {
      console.log('Task added successfully');
      // Clear the form or display a success message
      fetchAndDisplayTasks(); // Refresh the task list
    } else {
      console.error('Error adding task');
    }
  })
  .catch(error => {
    console.error('Error:', error);
  });
});

//userLogOut
function logout() {
  localStorage.removeItem('token');
  window.location.href = '/login';
}

//edit
const editButtons = document.querySelectorAll('.edit-task');
editButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the task ID from the data attribute or other means
    const taskId = button.dataset.taskId;

    // Redirect to the edit tax page or open an edit form on the dashboard
    window.location.href = `/edit-task/${taskId}`; // Replace with your desired URL
  });
});

//delete
const deleteButtons = document.querySelectorAll('.delete-task');
deleteButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the task ID from the data attribute or other means
    const taskId = button.dataset.taskId;

    // Send a request to delete the task from the server
    fetch(`/tasks/${taskId}`, {
      method: 'DELETE'
    })
    .then(response => {
      if (response.ok) {
        // Remove the task from the dashboard
        button.closest('li').remove();
      } else {
        console.error('Error deleting task');
      }
    });
  });
});

//filter by
router.get('/tasks', async (req, res) => {
  const { priority, deadline } = req.query;
  let query = {};

  if (priority) {
    query.priority = priority;
  }

  if (deadline) {
    query.deadline = deadline;
  }

  try {
    const tasks = await Task.find(query);
    res.json(tasks);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});
const filterButton = document.getElementById('filter-button');
filterButton.addEventListener('click', () => {
  const filterBy = document.getElementById('filter-by').value;
  const filterValue = document.getElementById('filter-value').value;

  // Create the query parameters based on the filter
  const queryParams = new URLSearchParams();
  if (filterBy === 'priority') {
    queryParams.append('priority', filterValue);
  } else if (filterBy === 'deadline') {
    queryParams.append('deadline', filterValue);
  }

  const url = `/tasks?${queryParams.toString()}`;

  fetch(url)
    .then(response => response.json())
    .then(filteredTasks => {
      // Update the dashboard UI with the filtered tasks
      const tasksList = document.getElementById('tasks-list');
      tasksList.innerHTML = '';

      filteredTasks.forEach(task => {
        // ... create list items for filtered tasks ...
      });
    })
    .catch(error => {
      console.error('Error fetching tasks:', error);
    });
});

//search funtionality
const searchInput = document.getElementById('search-input');
searchInput.addEventListener('keyup', () => {
  const searchTerm = searchInput.value.toLowerCase();
  const tasksList = document.getElementById('tasks-list');
  const allTaskItems = tasksList.querySelectorAll('li');

  allTaskItems.forEach(taskItem => {
    const taskTitle = taskItem.textContent.toLowerCase();
    if (taskTitle.includes(searchTerm)) {
      taskItem.style.display = 'block';
    } else {
      taskItem.style.display = 'none';
    }
  });
});

// ... generate report ...
const generateReportButton = document.getElementById('generate-report-button');
const reportContent = document.getElementById('report-content');

generateReportButton.addEventListener('click', () => {
  fetch('/generate-report')
    .then(response => response.json())
    .then(reportData => {
      // Display the report data in the report content section
      reportContent.innerHTML = reportData; // Replace with your desired way to display the report
    })
    .catch(error => {
      console.error('Error generating report:', error);
    });
});


fetch('/generate-report')
  .then(response => response.json())
  .then(reportData => {
    // Create the HTML table structure
    const table = document.createElement('table');
    const tableHead = document.createElement('thead');
    const tableBody = document.createElement('tbody');
    table.appendChild(tableHead);
    table.appendChild(tableBody);

    // Create table headers
    const headerRow = document.createElement('tr');
    // Add table headers based on your report data structure
    headerRow.innerHTML = `
      <th>Task Title</th>
      <th>Task Amount</th>
      `;
    tableHead.appendChild(headerRow);

    // Create table rows for each task
    reportData.forEach(task => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${task.title}</td>
        <td>${task.amount}</td>
        `;
      tableBody.appendChild(row);
    });

    // Display the table in the report content section
    reportContent.innerHTML = '';
    reportContent.appendChild(table);
  })
  .catch(error => {
    console.error('Error generating report:', error);
  });