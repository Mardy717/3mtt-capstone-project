const loginForm = document.getElementById('login-form');
loginForm.addEventListener('submit', function(event) {
  event.preventDefault();

  // Get form values
  const Email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Basic validation
  if (Email === '') {
    alert('Please enter your email');
    return;
  }

  if (password === '') {
    alert('Please enter your password');
    return;
  }

  // Email validation (basic check)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (emailRegex.test(Email) === false) {
    alert('Please enter a valid email address');
    return;
  }

  // Password validation
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (passwordRegex.test(password) === false) {
    alert('Password must be at least 8 characters long and contain at least one letter, one number, and one special character');
    return;
  }

  // Form is valid, submit data to server
  // ... form validation ...
const formData = {
    Email: EmailInput.value,
    password: passwordInput.value,
    rememberMe: rememberMeCheckbox.checked
};

fetch('/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
})
.then(response => {
    if (response.ok) {
        console.log('Login successful');
        // Handle successful login, e.g., redirect to dashboard
    } else {
        console.error('Login failed');
        // Handle login error
    }
})
.catch(error => {
    console.error('Error:', error);
});

});
