const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = process.env.PORT || 3000;
const task = require('.config');
const user = require('.config');


app.use(express.json());

// Middleware
app.use(bodyParser.json());

// Routes (import and use your routes here)
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);
app.use('/', (req, res) => {
  res.render('/index');
});
app.use('/', (req, res) => {
  res.render('/login');
});

app.use(express.static('public'));


app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});